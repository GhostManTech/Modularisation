from time import *
try:
	from math import *
	from tkinter import *
	from turtle import *
	import platform
	import os
	import datetime
	import pygame
except ImportError:
	print("Erreur d'importation des modules supplémentaires...")
	sleep(3)
else:
	def function_multiplications(table=8, divisions=200):
		canvas = Canvas(root, width=800, height=750, borderwidth=0, relief="solid", background="#FFFFFF")
		canvas.place(x=200, y=-1)
		turtle = RawTurtle(canvas)
		sizeCircle = 300
		pygame.init()
		music = pygame.mixer.music.load("LIB/SOUND/sound.wav")
		try:
			table = int(enterTable.get())
			divisions = int(enterDivisions.get())
		except Exception as error:
			labelChargement.config(text=(""), foreground="#FFFFFF")
			labelIndication.config(text=(""), foreground="#FFFFFF")
			timePosition.config(text=(""))
			timeDraw.config(text=(""))
			root.title("ARITHMÉTIQUE MODULAIRE | TABLE DE {} MODULE {}".format(table, modulo))
			turtle.speed(0)
			turtle.width(3)
			turtle.hideturtle()
			turtle.up()
			turtle.goto(0, -sizeCircle)
			turtle.down()
			turtle.circle(sizeCircle)
			turtle.up()
			perimetre = pi * sizeCircle
			avancer = 180 / divisions * 2
			positions = []
			varStart = datetime.datetime.utcnow()
			for i in range(1, divisions+1):
				labelChargement.config(text=("En cours..."))
				turtle.goto(0, -sizeCircle)
				turtle.setheading(0)
				turtle.circle(sizeCircle, avancer*i)
				positions.append(turtle.pos())
				turtle.goto(0, 0)
			turtle.down()
			turtle.width(1)
			varEnd = datetime.datetime.utcnow()
			time = varEnd-varStart
			pygame.mixer.music.play(-1)
			sleep(0.15)
			pygame.mixer.music.stop()
			labelChargement.config(text=("Calcul des positions     [ OK ]"), foreground="#00FF00")
			timePosition.config(text=("Temps écoulé : {}".format(time)))
			varStart = datetime.datetime.utcnow()
			for i in range(len(positions)):
				labelIndication.config(text=("En cours..."))
				j = i
				while(j >= len(positions)):
					j -= len(positions)
				turtle.goto(positions[j])
						
				index = i*table
				while(index >= len(positions)):
					index -= len(positions)
				turtle.goto(positions[index])
			varEnd = datetime.datetime.utcnow()
			time = varEnd-varStart
			pygame.mixer.music.play(-1)
			sleep(0.15)
			pygame.mixer.music.stop()
			labelIndication.config(text=("Traçage de la figure      [ OK ]"), foreground="#00FF00")
			timeDraw.config(text=("Temps écoulé : {}".format(time)))
		else:
			labelChargement.config(text=(""), foreground="#FFFFFF")
			labelIndication.config(text=(""), foreground="#FFFFFF")
			timePosition.config(text=(""))
			timeDraw.config(text=(""))
			root.title("ARITHMÉTIQUE MODULAIRE | TABLE DE {} MODULO {}".format(table, divisions))
			turtle.speed(0)
			turtle.width(3)
			turtle.hideturtle()
			turtle.up()
			turtle.goto(0, -sizeCircle)
			turtle.down()
			turtle.circle(sizeCircle)
			turtle.up()
			perimetre = pi * sizeCircle
			avancer = 180 / divisions * 2
			positions = []
			varStart = datetime.datetime.utcnow()
			for i in range(1, divisions+1):
				labelChargement.config(text=("En cours..."))
				turtle.goto(0, -sizeCircle)
				turtle.setheading(0)
				turtle.circle(sizeCircle, avancer*i)
				positions.append(turtle.pos())
				turtle.goto(0, 0)
			turtle.down()
			turtle.width(1)
			varEnd = datetime.datetime.utcnow()
			time = varEnd-varStart
			pygame.mixer.music.play(-1)
			sleep(0.15)
			pygame.mixer.music.stop()
			labelChargement.config(text=("Calcul des positions     [ OK ]"), foreground="#00FF00")
			timePosition.config(text=("Temps écoulé : {}".format(time)))
			varStart = datetime.datetime.utcnow()
			for i in range(len(positions)):
				labelIndication.config(text=("En cours..."))
				j = i
				while(j >= len(positions)):
					j -= len(positions)
				turtle.goto(positions[j])
						
				index = i*table
				while(index >= len(positions)):
					index -= len(positions)
				turtle.goto(positions[index])
			varEnd = datetime.datetime.utcnow()
			time = varEnd-varStart
			timeDraw.config(text=("Temps écoulé: {}".format(time)))
			pygame.mixer.music.play(-1)
			sleep(0.15)
			pygame.mixer.music.stop()
			labelIndication.config(text=("Traçage de la figure      [ OK ]"), foreground="#00FF00")
	def representations(event):
		function_multiplications()
		
	root = Tk()
	choiceTable = 8
	modulo = 200
	root.title("ARITHMÉTIQUE MODULAIRE | TABLE DE {} MODULO {}".format(choiceTable, modulo))
	root.geometry("1000x750")
	root.resizable(width=False, height=False)
	root.config(bg="#24292E")
	canvas = Canvas(root, width=800, height=750, borderwidth=0, relief="solid", background="#FFFFFF")
	canvas.place(x=200, y=-1)
	if platform.system() == "Windows":
		root.iconbitmap("LIB/IMG/icone.ico")
	labelDivisions = Label(root, text="MODULO", background="#24292E", foreground="#FFFFFF")
	labelDivisions.place(x=8, y=80)
	labelTables = Label(root, text="TABLE", background="#24292E", foreground="#FFFFFF")
	labelTables.place(x=8, y=30)
	timePosition = Label(root, text=(""), foreground="#909090", background="#24292E")
	timePosition.place(x=9, y=270)
	timeDraw = Label(root, text=(""), foreground="#909090", background="#24292E")
	timeDraw.place(x=9, y=310)
	enterDivisions = Entry(root, width=20, relief="solid", background="#FFFFFF", foreground="#000000", selectbackground="#FF0000")
	enterDivisions.place(x=10, y=100)
	enterTable = Entry(root, width=20, relief="solid", background="#FFFFFF", foreground="#000000", selectbackground="#FF0000")
	enterTable.place(x=10, y=50)
	labelChargement = Label(root, text=(""), background="#24292E", foreground="#787878")
	labelChargement.place(x=9, y=250)
	labelIndication = Label(root, text=(""), background="#24292E", foreground="#787878")
	labelIndication.place(x=9, y=290)
	buttonConvert = Button(root, width=20, text="VOIR LE RENDU", activebackground="#FF0000", activeforeground="#000000", background="#FFFFFF", foreground="#000000", command=function_multiplications, relief="solid")
	buttonConvert.place(x=10, y=200)
	root.bind("<Return>", representations)
	root.mainloop()

finally:
	print("Fin du programme")
	sleep(3)
